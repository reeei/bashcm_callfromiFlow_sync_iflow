import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

// import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
def Message processData(Message message) {
    Map<String, String> headerToFieldMap = new HashMap<String, String>() {
		{
            put("会社コード", "会社コード");
            put("会計伝票タイプ", "会計伝票タイプ");
            put("元帳グループ", "元帳グループ");
            put("参照ID", "参照ID");
            put("ヘッダテキスト", "ヘッダテキスト");
            put("伝票日付", "伝票日付");
            put("転記日付", "転記日付");
            put("換算日付", "換算日付");
            put("換算レート", "換算レート");
            put("明細番号", "明細番号");
            put("GL勘定コード", "GL勘定コード");
            put("取引通貨額", "取引通貨額");
            put("税額", "税額");
            put("取引通貨", "取引通貨");
            put("取引タイプ", "取引タイプ");
            put("税コード", "税コード");
            put("取引先コード", "取引先コード");
            put("起算日", "起算日");
            put("明細テキスト", "明細テキスト");
            put("ソートキー", "ソートキー");
            put("原価センタ", "原価センタ");
            put("利益センタ", "利益センタ");
            put("WBS要素", "WBS要素");
            put("指図", "指図");
            put("セグメント", "セグメント");
            put("機能領域", "機能領域");
            put("従業員番号", "従業員番号");
            put("取引銀行", "取引銀行");
            put("取引銀行口座", "取引銀行口座");
            put("参照キー1", "参照キー1");
            put("参照キー2", "参照キー2");
            put("参照キー3", "参照キー3");
            put("得意先(収益性分析)", "得意先(収益性分析)");
            put("得意先グループ(収益性分析)", "得意先グループ(収益性分析)");
            put("顧客業界(収益性分析)", "顧客業界(収益性分析)");
            put("顧客国(収益性分析)", "顧客国(収益性分析)");
            put("販売地域(収益性分析)", "販売地域(収益性分析)");
            put("販売済み品目(収益性分析)", "販売済み品目(収益性分析)");
            put("販売済み品目グループ(収益性分析)", "販売済み品目グループ(収益性分析)");
            put("販売組織(収益性分析)", "販売組織(収益性分析)");
            put("流通チャネル(収益性分析)", "流通チャネル(収益性分析)");
            put("WBS要素(収益性分析)", "WBS要素(収益性分析)");
            put("機能領域(収益性分析)", "機能領域(収益性分析)");
            put("受注(収益性分析)", "受注(収益性分析)");
            put("受注明細(収益性分析)", "受注明細(収益性分析)");
            put("プラント(収益性分析)", "プラント(収益性分析)");
            put("原価センタ(収益性分析)", "原価センタ(収益性分析)");
            put("利益センタ(収益性分析)", "利益センタ(収益性分析)");
            put("得意先", "得意先");
            put("期日計算基準日", "期日計算基準日");
            put("現金割引期間 1", "現金割引期間 1");
            put("現金割引率 1", "現金割引率 1");
            put("現金割引期間 2", "現金割引期間 2");
            put("現金割引率 2", "現金割引率 2");
            put("支払条件", "支払条件");
            put("支払方法", "支払方法");
            put("支払保留", "支払保留");
            put("中央銀行コード", "中央銀行コード");
            put("特殊仕訳コード", "特殊仕訳コード");
            put("仕入先", "仕入先");
            put("パートナ銀行タイプ", "パートナ銀行タイプ");
            put("名称(ワンタイム)", "名称(ワンタイム)");
            put("名称3(ワンタイム)", "名称3(ワンタイム)");
            put("市区町村(ワンタイム)", "市区町村(ワンタイム)");
            put("銀行の国/地域(ワンタイム)", "銀行の国/地域(ワンタイム)");
            put("口座番号(ワンタイム)", "口座番号(ワンタイム)");
            put("預金種別(ワンタイム)", "預金種別(ワンタイム)");
            put("銀行コード(ワンタイム)", "銀行コード(ワンタイム)");
            put("手数料負担Code(ワンタイム)", "手数料負担Code(ワンタイム)");
            put("言語キー(ワンタイム)", "言語キー(ワンタイム)");
            put("源泉徴収税タイプ", "源泉徴収税タイプ");
            put("源泉徴収税コード", "源泉徴収税コード");
            put("源泉徴収税基準額", "源泉徴収税基準額");
            put("源泉徴収税額", "源泉徴収税額");
		}
	};
	Map<Integer, String> indexToFieldMap = new HashMap<Integer, String>();
// 	String NSURL = "https://mdpgroup.com";
	def body = message.getBody(String.class);
    // byte[] data = java.util.Base64.getDecoder().decode(body)
    Document doc = newDocument();
// //     Element rootEl = doc.createElementNS(NSURL,
// // 				"ns1:MT_3RD_MDPGROUP_CPI_ORDER");
// // 	doc.appendChild(rootEl);
    XSSFWorkbook workbook = new XSSFWorkbook();
    // def workbookBase64 = java.util.Base64.getEncoder().encode(body)
    // Workbook workbook = new XSSFWorkbook();
// 	Workbook workbook = new XSSFWorkbook( new ByteArrayInputStream(body));

	String sheetName = "Sheet1";
	// workbook.getSheetAt(1);
// 	Sheet sheet = workbook.getSheet(sheetName);
// 	for (Row row : sheet) {

// 			// System.out.println(row.getRowNum());
// 			// if(row.getRowNum()==0) {
// 			// continue;
// 			// }

// 			// ADD A NEW ROW
// // 			Element itemEl = doc.createElementNS("", "order");

// // 			for (Cell cell : row) {
// // 				String cellValue = null;
// // 				switch (cell.getCellTypeEnum()) {
// // 				case CellType.STRING:
// // 					// System.out.println(cell.getStringCellValue());
// // 					cellValue = cell.getStringCellValue();
// // 					break;
// // 				case CellType.NUMERIC:
// // 					// System.out.println(cell.getNumericCellValue());
// // 					cellValue = String.valueOf(cell.getNumericCellValue());
// // 					break;
// // 				// case BOOLEAN: ... break;
// // 				// case FORMULA: ... break;
// // 				default:
// // 					System.out.println("CELL TYPE NOT USED!");
// // 				}

// // 				if (cellValue != null) {
// // 					// use the first row for header -> fieldname mapping
// // 					if (row.getRowNum() == 0) {
// // 						indexToFieldMap.put(cell.getColumnIndex(),
// // 								headerToFieldMap.get(cellValue));
// // 						continue;
// // 					}
// // 					// add item if it is not header.
// // 					rootEl.appendChild(itemEl);
// // 					// System.out.println(cellValue);
// // 					Element fieldEl = doc.createElementNS("", indexToFieldMap.get(cell.getColumnIndex()));
// // 					itemEl.appendChild(fieldEl);
// // 					fieldEl.setTextContent(cellValue);
// // 				}
// // 			}
// // 		}
    // message.setBody(doc);
    // message.setBody(workbookBase64);
        // message.setBody(doc)

   return message;
}


public static Document newDocument() throws ParserConfigurationException {
	DocumentBuilderFactory factory;
	DocumentBuilder builder;
	try {
		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		return builder.newDocument();

	} finally {
		builder = null;
		factory = null;
	}
}














































