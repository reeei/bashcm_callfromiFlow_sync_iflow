import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    //Body
    def response = message.getBody(java.lang.String);
    def responseXML = new XmlParser().parseText(response);
    def properties = message.getProperties();
    def inputdata = properties.get("inputdataXML")
    def inputdataXML = new XmlParser().parseText(inputdata);
    def logMessage = "";
    responseXML.JournalEntryCreateConfirmation.each{Confirmation->
        def referenceId = Confirmation.MessageHeader.ReferenceID.text();
        def logLevel = Confirmation.Log.MaximumLogItemSeverityCode.text();
        if(logLevel == 3){
            Confirmation.Log.each{Item->
                logMessage = logMessage + Item.Note.text();
            }
        }else{
            logMessage = Confirmation.Log.Item.Note.text();
        }
        inputdataXML.each{Record->
            if(Record.Column4.text() == referenceId){
                Record.appendNode("logMessage", logMessage);
                println(logLevel);
                if(logLevel == "3"){
                    Record.appendNode("logResult", "NG");
                    println(logMessage)
                }else{
                    Record.appendNode("logResult", "OK");
                    println(logMessage)
                }
            }
        }
        logMessage = "";
        logLevel = "";
        message.setBody(XmlUtil.serialize(inputdataXML));
    }
    return message;
}