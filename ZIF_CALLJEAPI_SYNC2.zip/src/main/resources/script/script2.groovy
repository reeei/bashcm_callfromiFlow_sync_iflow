import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.InputStream

def Message processData(Message message) {
//     //Body
//     def body = message.getBody();
// /*To set the body, you can use the following method. Refer SCRIPT APIs document for more detail*/
//     //message.setBody(body + " Body is modified");
//     //Headers
//     def headers = message.getHeaders();
//     def value = headers.get("oldHeader");
//     message.setHeader("oldHeader", value + " modified");
//     message.setHeader("newHeader", "newHeader");
//     //Properties
//     def properties = message.getProperties();
//     value = properties.get("oldProperty");
//     message.setProperty("oldProperty", value + " modified");
//     message.setProperty("newProperty", "newProperty");
//     return message;
    // Example usage: Assume 'body' contains the Excel file input stream
    def excelInputStream = message.getBody(InputStream)
    def sheetNames = getSheetNamesFromExcel(excelInputStream)

// Log the sheet names
    sheetNames.each { sheetName ->
        messageLog.addAttachmentAsString("Sheet Name", sheetName, "text/plain")
    }
}


def getSheetNamesFromExcel(InputStream inputStream) {
    // Create a workbook instance from the Excel file
    def workbook = WorkbookFactory.create(inputStream);

    // Get the sheet names
    def sheetNames = []
    for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
        sheetNames.add(workbook.getSheetName(i))
    }
    workbook.close()
    return sheetNames
}

